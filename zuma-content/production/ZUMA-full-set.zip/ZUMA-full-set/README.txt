ZUMA: full production set (4 Nov 2026)

Every printed piece, as Illustrator files (.ai, PDF-based: type converted to outlines, exact page size with a trim box).
Each folder has its message or quote request for that supplier, and previews.

1-vial-labels     12 wrap labels, Rev 4. 43 x 20 mm (65 x 30.2 mm for BAC water and NAD+). Matte white, waterproof.
2-round-stickers  12 round compound stickers, 16 mm, Lightbox + crest + name round the edge, no border. Die cut on CutContour.
3-vacuum-bag      Tinted vacuum bag, 100 x 150 mm, holds two vials. Fronts in red, blue, grey (see-through colour + white ink), one shared back.
4-box             One box for every product: the plain carton in ZUMA blue #1E74A8, 20 x 20 x 40 mm inside. The round sticker names the compound.
5-mailer          Bubble mailer #0 (6 x 10 in + 44 mm flap): white film, one spot ink (ZUMA Oxblood), palm back, bamboo front.

Oxblood is #6E1C2A everywhere: ask each printer to match it and tell you the Pantone they use.
Supplier prices are not kept in these files.
For laboratory research use only. Not for human or veterinary use.
